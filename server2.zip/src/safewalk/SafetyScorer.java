package safewalk;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 윤신혁 모델 — safety.js 의 안전 점수 로직을 서버로 옮긴 것.
 *
 * 원본(안드로이드용)은 org.json 을 썼으나 서버에는 없으므로 safewalk.Json 으로 바꾸었다.
 * 알고리즘(가중치·반경·보간 간격·부족도 식·알파 선택)은 원본 그대로다.
 *
 * 사용 흐름:
 *   SafetyScorer sc = new SafetyScorer(dataDir);
 *   sc.calibrateSRef(graph);                       // 실제 분포의 p50 으로 기준값 보정
 *   double[] deficit = sc.edgeDeficits(graph);     // 간선별 안전 부족도 (0~1, 낮을수록 안전)
 *   double[] w = SafetyScorer.weights(graph, deficit, alpha);
 *   Dijkstra.shortestPath(graph, src, dst, w);
 */
public class SafetyScorer {

    public static final int CCTV = 0, BELL = 1, POLICE = 2;
    private static final double[] WEIGHT = {1.0, 0.5, 1.4};   // 종류별 가중치
    private static final double[] RADIUS = {150, 120, 300};   // 종류별 영향 반경(m)

    private static final String[] FILES = {"cctv.geojson", "bell.geojson", "police.geojson"};

    /* ── 튜닝 값 (원본 DEFAULTS 와 동일) ── */
    public double step = 20;            // 간선 보간 간격(m)
    public double sRef = 2.5;           // 안전도 정규화 기준 (calibrateSRef 로 보정)
    public double weakThreshold = 0.3;  // 안전도가 이 값 미만이면 취약 지점
    public double hitOffset = 60;       // "경로 위 시설"로 볼 거리(m)

    /* 광주 범위 밖 좌표(이상치) 제거용 */
    private static final double LAT_MIN = 35.0, LAT_MAX = 35.30, LNG_MIN = 126.6, LNG_MAX = 127.1;

    /* 격자: 셀 크기(약 355m) > 최대 반경(300m) 이므로 주변 3x3 만 보면 충분 */
    private static final double CELL_LAT = 0.0032, CELL_LNG = 0.0039;

    private static final class Facility {
        final double lat, lng, w, radius, cnt;
        final int type;
        Facility(double lat, double lng, int type, double w, double cnt) {
            this.lat = lat; this.lng = lng; this.type = type;
            this.w = w; this.radius = RADIUS[type]; this.cnt = cnt;
        }
    }

    private interface Visitor { void visit(Facility f, double distM); }

    private final Map<Long, List<Facility>> grid = new HashMap<>();
    private final int facilityCount;

    public SafetyScorer(Path dataDir) {
        List<Facility> all = new ArrayList<>();
        for (int type = 0; type < FILES.length; type++) {
            Path p = dataDir.resolve(FILES[type]);
            if (!Files.exists(p)) {
                System.out.println("[safety] " + FILES[type] + " 없음 — 건너뜀");
                continue;
            }
            try {
                int before = all.size();
                read(p, type, all);
                System.out.printf("[safety] %s %,d지점%n", FILES[type], all.size() - before);
            } catch (Exception e) {
                System.out.println("[safety] " + FILES[type] + " 읽기 실패: " + e.getMessage());
            }
        }
        facilityCount = all.size();
        for (Facility f : all) {
            long k = key((int) Math.floor(f.lat / CELL_LAT), (int) Math.floor(f.lng / CELL_LNG));
            grid.computeIfAbsent(k, x -> new ArrayList<>()).add(f);
        }
    }

    public int facilityCount() { return facilityCount; }

    private static long key(int i, int j) { return ((long) i << 32) | (j & 0xffffffffL); }

    /* ───────────────────── 로딩 ───────────────────── */

    private static void read(Path path, int type, List<Facility> out) throws IOException {
        String text = new String(Files.readAllBytes(path), StandardCharsets.UTF_8);
        Map<String, Object> root = Json.asMap(Json.parse(text));
        List<Object> feats = root == null ? null : Json.asList(root.get("features"));
        if (feats == null) throw new IOException("features 배열이 없습니다");

        for (Object fo : feats) {
            Map<String, Object> f = Json.asMap(fo);
            if (f == null) continue;
            Map<String, Object> geom = Json.asMap(f.get("geometry"));
            if (geom == null || !"Point".equals(geom.get("type"))) continue;
            List<Object> c = Json.asList(geom.get("coordinates"));
            if (c == null || c.size() < 2) continue;

            double lng = Json.asDouble(c.get(0), 0);   // geojson 은 [경도, 위도]
            double lat = Json.asDouble(c.get(1), 0);
            if (lat < LAT_MIN || lat > LAT_MAX || lng < LNG_MIN || lng > LNG_MAX) continue;

            Map<String, Object> props = Json.asMap(f.get("properties"));
            double cnt = Math.max(1, firstNonZero(props, "cnt", "수량", "count"));

            // CCTV 대수는 로그로 포화: 1대=1.0, 4대=1.5, 16대=2.0
            double mult = type == CCTV ? 1 + 0.5 * (Math.log(cnt) / Math.log(4)) : 1;
            out.add(new Facility(lat, lng, type, WEIGHT[type] * mult, cnt));
        }
    }

    private static double firstNonZero(Map<String, Object> props, String... keys) {
        if (props == null) return 1;
        for (String k : keys) {
            if (!props.containsKey(k)) continue;
            double v = Json.asDouble(props.get(k), 0);
            if (v != 0 && !Double.isNaN(v)) return v;
        }
        return 1;
    }

    /* ───────────────────── 점수 ───────────────────── */

    private static double haversine(double la1, double lo1, double la2, double lo2) {
        double dLat = Math.toRadians(la2 - la1), dLng = Math.toRadians(lo2 - lo1);
        double x = Math.pow(Math.sin(dLat / 2), 2)
                + Math.cos(Math.toRadians(la1)) * Math.cos(Math.toRadians(la2))
                  * Math.pow(Math.sin(dLng / 2), 2);
        return 2 * 6371000.0 * Math.asin(Math.sqrt(x));
    }

    private void eachNearby(double lat, double lng, Visitor fn) {
        int ci = (int) Math.floor(lat / CELL_LAT), cj = (int) Math.floor(lng / CELL_LNG);
        for (int i = ci - 1; i <= ci + 1; i++) {
            for (int j = cj - 1; j <= cj + 1; j++) {
                List<Facility> cell = grid.get(key(i, j));
                if (cell == null) continue;
                for (Facility f : cell) fn.visit(f, haversine(lat, lng, f.lat, f.lng));
            }
        }
    }

    /** 한 지점의 안전 점수 (시설이 가까울수록 높음) */
    public double nodeScore(double lat, double lng) {
        final double[] s = {0};
        eachNearby(lat, lng, (f, d) -> {
            if (d < f.radius) s[0] += f.w * (1 - d / f.radius);
        });
        return s[0];
    }

    /**
     * sRef 를 실제 분포의 중앙값(p50)으로 맞춘다.
     * 원본의 기본값 2.5 는 가짜 데이터 기준이라, 실제 데이터에서는 보정해야 한다고 안내받았다.
     * 0 이 되면 나눗셈이 깨지므로 하한을 둔다.
     */
    public double calibrateSRef(RoadGraph g) {
        double[] s = new double[g.nodeCount];
        for (int i = 0; i < g.nodeCount; i++) s[i] = nodeScore(g.lat[i], g.lon[i]);
        Arrays.sort(s);
        double p50 = s[s.length / 2];
        sRef = Math.max(0.1, p50);
        return sRef;
    }

    /** 꺾은선 [{lat,lng}...] 을 step(m) 간격으로 촘촘하게 */
    private List<double[]> resample(List<double[]> path) {
        List<double[]> out = new ArrayList<>();
        if (path.isEmpty()) return out;
        out.add(path.get(0));
        for (int i = 0; i < path.size() - 1; i++) {
            double[] a = path.get(i), b = path.get(i + 1);
            long n = Math.max(1, Math.round(haversine(a[0], a[1], b[0], b[1]) / step));
            for (long k = 1; k <= n; k++) {
                double t = (double) k / n;
                out.add(new double[]{a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t});
            }
        }
        return out;
    }

    /**
     * 간선별 안전 부족도 = 0.5 x (1 - 평균안전도) + 0.5 x 취약지점비율   (0~1, 낮을수록 안전)
     * 서버 기동 시 한 번만 계산해 두고 재사용한다.
     */
    public double[] edgeDeficits(RoadGraph g) {
        double[] def = new double[g.arcCount];
        for (int a = 0; a < g.arcCount; a++) {
            List<double[]> line = new ArrayList<>();
            double[] ll = g.geom[a];
            if (ll == null || ll.length < 4) {
                line.add(new double[]{g.lat[g.from[a]], g.lon[g.from[a]]});
                line.add(new double[]{g.lat[g.to[a]], g.lon[g.to[a]]});
            } else {
                for (int i = 0; i + 1 < ll.length; i += 2) line.add(new double[]{ll[i], ll[i + 1]});
            }
            List<double[]> pts = resample(line);
            double sum = 0;
            int weak = 0;
            for (double[] p : pts) {
                double level = Math.min(1, nodeScore(p[0], p[1]) / sRef);
                sum += level;
                if (level < weakThreshold) weak++;
            }
            double mean = sum / pts.size();
            def[a] = 0.5 * (1 - mean) + 0.5 * ((double) weak / pts.size());
        }
        return def;
    }

    /** 다익스트라에 넘길 간선 비용: 거리 x (1 + alpha x 부족도). alpha=0 이면 순수 거리 */
    public static double[] weights(RoadGraph g, double[] deficit, double alpha) {
        double[] w = new double[g.arcCount];
        for (int a = 0; a < g.arcCount; a++) w[a] = g.length[a] * (1 + alpha * deficit[a]);
        return w;
    }

    /**
     * 경로 좌표 [{lat,lng}...] 주변(hitOffset 이내) 시설 수. 같은 시설은 한 번만 센다.
     * @return {CCTV 대수, 비상벨 개수, 경찰서 개수}
     */
    public int[] countNear(List<double[]> coords) {
        final Set<Facility> seen = Collections.newSetFromMap(new IdentityHashMap<Facility, Boolean>());
        final int[] cnt = new int[3];
        for (double[] p : resample(coords)) {
            eachNearby(p[0], p[1], (f, d) -> {
                if (d <= hitOffset && seen.add(f)) {
                    cnt[f.type] += f.type == CCTV ? (int) Math.round(f.cnt) : 1;
                }
            });
        }
        return cnt;
    }
}
