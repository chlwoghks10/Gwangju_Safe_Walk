package safewalk;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;

/**
 * 광주 안심길 — 경로 비교 API 서버 (자바)
 *
 * 팀원이 작성한 RoadGraph / Dijkstra 를 그대로 사용하고,
 * JDK 내장 HttpServer 로 감싸 외부 라이브러리 없이 동작한다.
 *
 * 빌드   javac -encoding UTF-8 -d out src/safewalk/*.java
 * 실행   java -cp out safewalk.Server [포트] [데이터폴더]
 * 확인   http://<주소>:8000/health
 */
public class Server {

    /** 요청 좌표가 도로망에서 이만큼 멀면 거부 */
    private static final double MAX_SNAP_METERS = 300.0;

    /** 윤신혁 모델: 최단 대비 허용 우회율, 그리고 시도할 알파(안전 가중치) 값 */
    private static final double MAX_DETOUR = 1.35;
    private static final double[] ALPHAS = {3.0, 2.0, 1.0, 0.5};

    private static RoadGraph graph;
    private static Facilities facilities;
    private static SafetyScorer scorer;      // 윤신혁 모델
    private static double[] deficit;         // 간선별 안전 부족도 (기동 시 1회 계산)

    public static void main(String[] args) throws Exception {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : 8000;
        Path dataDir = Paths.get(args.length > 1 ? args[1] : "data");

        long t0 = System.nanoTime();
        try (InputStream nodes = Files.newInputStream(dataDir.resolve("graph_nodes.csv"));
             InputStream edges = Files.newInputStream(dataDir.resolve("graph_edges.csv"))) {
            graph = RoadGraph.load(nodes, edges);
        }
        System.out.printf("[graph] 노드 %,d / 간선 %,d  (%.0fms)%n",
                graph.nodeCount, graph.arcCount, (System.nanoTime() - t0) / 1e6);

        facilities = new Facilities(dataDir);

        long t1 = System.nanoTime();
        scorer = new SafetyScorer(dataDir);
        double sref = scorer.calibrateSRef(graph);
        deficit = scorer.edgeDeficits(graph);
        System.out.printf("[safety] 시설 %,d지점 / sRef %.3f / 부족도 평균 %.3f  (%.0fms)%n",
                scorer.facilityCount(), sref, mean(deficit), (System.nanoTime() - t1) / 1e6);

        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/health", Server::handleHealth);
        server.createContext("/route",  Server::handleRoute);
        server.createContext("/",       Server::handleRoot);
        server.setExecutor(Executors.newFixedThreadPool(4));
        server.start();

        System.out.println("[server] http://0.0.0.0:" + port + " 에서 대기 중");
    }

    /* ───────────── 엔드포인트 ───────────── */

    private static void handleRoot(HttpExchange ex) throws IOException {
        send(ex, 200, "{\"service\":\"광주 안심길 경로 API\",\"endpoints\":[\"/health\",\"/route\"]}");
    }

    private static void handleHealth(HttpExchange ex) throws IOException {
        double minLat = Double.MAX_VALUE, maxLat = -Double.MAX_VALUE;
        double minLon = Double.MAX_VALUE, maxLon = -Double.MAX_VALUE;
        for (int i = 0; i < graph.nodeCount; i++) {
            minLat = Math.min(minLat, graph.lat[i]); maxLat = Math.max(maxLat, graph.lat[i]);
            minLon = Math.min(minLon, graph.lon[i]); maxLon = Math.max(maxLon, graph.lon[i]);
        }

        StringBuilder b = new StringBuilder();
        b.append("{\"status\":\"ok\"");
        b.append(",\"nodes\":").append(graph.nodeCount);
        b.append(",\"arcs\":").append(graph.arcCount);
        b.append(",\"facility_layers\":{");
        boolean first = true;
        for (Map.Entry<String, Integer> e : facilities.layerSizes().entrySet()) {
            if (!first) b.append(',');
            first = false;
            b.append(Json.quote(e.getKey())).append(':').append(e.getValue());
        }
        b.append("},\"bounds\":{");
        b.append("\"min_lat\":").append(Json.num(minLat, 6));
        b.append(",\"max_lat\":").append(Json.num(maxLat, 6));
        b.append(",\"min_lon\":").append(Json.num(minLon, 6));
        b.append(",\"max_lon\":").append(Json.num(maxLon, 6));
        b.append("}}");
        send(ex, 200, b.toString());
    }

    private static void handleRoute(HttpExchange ex) throws IOException {
        long t0 = System.nanoTime();
        Map<String, String> q = query(ex.getRequestURI().getRawQuery());

        Double sLat = num(q.get("start_lat")), sLon = num(q.get("start_lon"));
        Double eLat = num(q.get("end_lat")),   eLon = num(q.get("end_lon"));
        if (sLat == null || sLon == null || eLat == null || eLon == null) {
            error(ex, 422, "start_lat, start_lon, end_lat, end_lon 이 모두 필요합니다");
            return;
        }
        boolean withFacilities = !"false".equalsIgnoreCase(q.getOrDefault("facilities", "true"));

        int src = graph.nearestNode(sLat, sLon);
        int dst = graph.nearestNode(eLat, eLon);
        double dSrc = graph.distanceToNode(src, sLat, sLon);
        double dDst = graph.distanceToNode(dst, eLat, eLon);

        if (dSrc > MAX_SNAP_METERS || dDst > MAX_SNAP_METERS) {
            error(ex, 400, String.format("도로망 범위 밖입니다 (출발 %.0fm, 도착 %.0fm)", dSrc, dDst));
            return;
        }
        if (src == dst) {
            error(ex, 400, "출발지와 도착지가 너무 가깝습니다");
            return;
        }

        Dijkstra.Result shortest = Dijkstra.shortestPath(graph, src, dst, graph.length);
        Dijkstra.Result safest   = Dijkstra.shortestPath(graph, src, dst, graph.safeCost);
        if (shortest == null || safest == null) {
            error(ex, 404, "두 지점이 도로망에서 이어지지 않습니다");
            return;
        }

        // 윤신혁 모델: 알파를 큰 값부터 시도해 최단 대비 MAX_DETOUR 이내인 첫 경로를 채택
        Dijkstra.Result safest2 = shortest;
        for (double alpha : ALPHAS) {
            Dijkstra.Result r = Dijkstra.shortestPath(graph, src, dst,
                    SafetyScorer.weights(graph, deficit, alpha));
            if (r != null && r.lengthM <= shortest.lengthM * MAX_DETOUR) { safest2 = r; break; }
        }

        boolean same  = java.util.Arrays.equals(shortest.arcs, safest.arcs);
        boolean same2 = java.util.Arrays.equals(shortest.arcs, safest2.arcs);

        StringBuilder b = new StringBuilder(1 << 16);
        b.append("{\"shortest\":");
        appendRoute(b, shortest, withFacilities);
        b.append(",\"safest\":");
        appendRoute(b, safest, withFacilities);
        b.append(",\"safest2\":");
        appendRoute(b, safest2, withFacilities);
        b.append(",\"same\":").append(same);
        b.append(",\"same2\":").append(same2);
        b.append(",\"extra_m\":").append(Json.num(safest.lengthM - shortest.lengthM, 1));
        b.append(",\"extra2_m\":").append(Json.num(safest2.lengthM - shortest.lengthM, 1));
        b.append(",\"elapsed_ms\":").append(Json.num((System.nanoTime() - t0) / 1e6, 1));
        b.append('}');
        send(ex, 200, b.toString());
    }

    /** 한 경로를 JSON 객체로 */
    private static void appendRoute(StringBuilder b, Dijkstra.Result r, boolean withFacilities) {
        List<double[]> coords = graph.coordsOf(r.arcs);
        Map<String, List<Facilities.Hit>> fac =
                withFacilities ? facilities.nearPolyline(coords) : new HashMap<>();

        b.append("{\"length_m\":").append(Json.num(r.lengthM, 1));
        b.append(",\"cctv\":").append(count(fac, "cctv"));
        b.append(",\"light\":").append(count(fac, "light"));
        b.append(",\"bell\":").append(count(fac, "bell"));
        b.append(",\"police\":").append(count(fac, "police"));

        b.append(",\"coords\":[");
        for (int i = 0; i < coords.size(); i++) {
            if (i > 0) b.append(',');
            double[] c = coords.get(i);
            b.append('[').append(Json.num(c[0], 6)).append(',').append(Json.num(c[1], 6)).append(']');
        }
        b.append(']');

        b.append(",\"facilities\":{");
        boolean firstLayer = true;
        for (Map.Entry<String, List<Facilities.Hit>> e : fac.entrySet()) {
            if (!firstLayer) b.append(',');
            firstLayer = false;
            b.append(Json.quote(e.getKey())).append(":[");
            List<Facilities.Hit> hits = e.getValue();
            for (int i = 0; i < hits.size(); i++) {
                if (i > 0) b.append(',');
                Facilities.Hit h = hits.get(i);
                b.append('[').append(Json.num(h.lat, 6)).append(',')
                 .append(Json.num(h.lon, 6)).append(',').append(h.cnt).append(']');
            }
            b.append(']');
        }
        b.append("}}");
    }

    private static double mean(double[] a) {
        double s = 0;
        for (double v : a) s += v;
        return a.length == 0 ? 0 : s / a.length;
    }

    /** 지점 수가 아니라 대수(개수) 합을 센다. 한 지점에 여러 대가 있으면 그만큼 더한다. */
    private static int count(Map<String, List<Facilities.Hit>> fac, String key) {
        List<Facilities.Hit> v = fac.get(key);
        if (v == null) return 0;
        int n = 0;
        for (Facilities.Hit h : v) n += h.cnt;
        return n;
    }

    /* ───────────── 보조 ───────────── */

    private static Map<String, String> query(String raw) {
        Map<String, String> m = new HashMap<>();
        if (raw == null || raw.isEmpty()) return m;
        for (String pair : raw.split("&")) {
            int i = pair.indexOf('=');
            if (i <= 0) continue;
            try {
                m.put(URLDecoder.decode(pair.substring(0, i), "UTF-8"),
                      URLDecoder.decode(pair.substring(i + 1), "UTF-8"));
            } catch (IOException ignored) { }
        }
        return m;
    }

    private static Double num(String s) {
        if (s == null || s.isEmpty()) return null;
        try { return Double.valueOf(s.trim()); } catch (NumberFormatException e) { return null; }
    }

    private static void error(HttpExchange ex, int code, String detail) throws IOException {
        send(ex, code, "{\"detail\":" + Json.quote(detail) + "}");
    }

    private static void send(HttpExchange ex, int code, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
        ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        ex.sendResponseHeaders(code, bytes.length);
        ex.getResponseBody().write(bytes);
        ex.close();
    }
}
