광주 안심길 — 경로 비교 API 서버 (자바)

[구성]
  src/safewalk/RoadGraph.java     윤해준 작성 (package 선언만 변경)
  src/safewalk/Dijkstra.java      윤해준 작성 (package 선언만 변경)
  src/safewalk/Facilities.java    경로 주변 시설 조회 (반경 10m, 좌표 중복 합침)
  src/safewalk/SafetyScorer.java  윤신혁 안전점수 모델 (safety.js 이식)
  src/safewalk/TmapRoute.java     윤신혁 Tmap 보행경로 호출 (RouteServer.java 이식)
  src/safewalk/Json.java          최소 JSON 도구
  src/safewalk/Server.java        HTTP 엔드포인트 (JDK 내장 HttpServer)
  data/                           graph_nodes.csv, graph_edges.csv
                                  + geojson 4개 (cctv/light/bell/police)

외부 라이브러리가 없어 Maven / Gradle 없이 javac 만으로 빌드된다.

[세 가지 경로]
  shortest  최단   거리만 본다
  safest    안심 A 윤해준 — 간선별 safeCost 로 다익스트라
  safest2   안심 B 윤신혁 — SafetyScorer 로 안전한 방향을 고르고,
                           그 방향을 경유지 3개로 Tmap 에 넘겨 실제 걸을 수 있는
                           골목 경로를 받아 온다. OSM 도로망에 없는 좁은 길이 들어온다.
                           Tmap 실패 / 키 없음 / 경로가 최단의 2.5배 초과 →
                           도로망 경로로 자동 대체 (safest2_source 로 구분)

  시설 개수는 세 경로 모두 같은 기준(반경 10m, 대수 합)으로 센다.

[EC2 준비]
  sudo apt update
  sudo apt install -y openjdk-21-jdk-headless

[Tmap 키 넣기 — EC2 에서 한 번만]
  echo 'TMAP_APP_KEY=발급받은키' > /home/ubuntu/safewalk.env
  chmod 600 /home/ubuntu/safewalk.env
  * 소스와 깃허브에는 키를 넣지 않는다. 공개 저장소의 키는 몇 분 안에 수집된다.

[빌드]
  javac -encoding UTF-8 -d out src/safewalk/*.java

[실행]
  TMAP_APP_KEY=발급받은키 java -Dstdout.encoding=UTF-8 -cp out safewalk.Server 8000 data

[항상 켜두기]
  sudo cp safewalk.service /etc/systemd/system/safewalk.service
  sudo systemctl daemon-reload
  sudo systemctl enable safewalk
  sudo systemctl restart safewalk
  sudo journalctl -u safewalk -n 30 --no-pager

  기동 로그에 다음이 보이면 정상이다:
    [graph]  노드 / 간선 개수
    [safety] 시설 지점 수 / sRef / 부족도 평균
    [tmap]   키 확인 — 안심 B 는 Tmap 보행 경로(골목 포함)로 그립니다

[확인]
  http://<주소>:8000/health
  http://<주소>:8000/route?start_lat=35.1445&start_lon=126.9245&end_lat=35.1360&end_lon=126.9310

[응답 형식]
  { "shortest": {length_m, cctv, light, bell, police, coords, facilities},
    "safest":   {...},            안심 A (윤해준)
    "safest2":  {...},            안심 B (윤신혁 + Tmap)
    "same": bool, "same2": bool,
    "safest2_source": "tmap" | "graph",
    "extra_m": ..., "extra2_m": ..., "elapsed_ms": ... }

  앱은 수정할 필요가 없다. safest2 의 coords 만 Tmap 경로로 바뀐다.
