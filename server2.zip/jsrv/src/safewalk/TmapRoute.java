package safewalk;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Tmap 보행자 경로 호출 (윤신혁 RouteServer.java 를 서버에 맞게 옮긴 것).
 *
 * 원본은 Gson 을 쓰고 포트 3000 에 따로 떴지만, 여기서는 외부 라이브러리 없이
 * safewalk.Json 으로 읽고 쓰며 기존 8000 번 서버 안에서 동작한다.
 *
 * 왜 필요한가 — OSM 도로망에는 좁은 골목이 빠져 있다. 안전한 "방향"은 우리 모델이 정하고,
 * 그 방향으로 실제 걸을 수 있는 길은 Tmap 이 그려준다. 경유지(passList)로 방향을 전달한다.
 *
 * 키는 환경변수 TMAP_APP_KEY 로 받는다. 소스에 적지 않는다.
 */
public final class TmapRoute {

    private static final String ENDPOINT =
            "https://apis.openapi.sk.com/tmap/routes/pedestrian?version=1&format=json";

    /** Tmap passList 제한 */
    public static final int MAX_VIA = 5;

    private final String appKey;
    private final HttpClient client;

    public TmapRoute(String appKey) {
        this.appKey = appKey;
        this.client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(4))
                .build();
    }

    public boolean enabled() {
        return appKey != null && !appKey.trim().isEmpty();
    }

    /** Tmap 이 돌려준 실제 보행 경로 */
    public static final class Result {
        public final List<double[]> path;    // {lat, lon} 좌표열
        public final double distanceM;       // Tmap 이 계산한 총 거리(m)
        public final double durationSec;     // Tmap 이 계산한 소요 시간(초)
        public final List<String> guides;    // "100m 앞 좌회전" 같은 안내 문구

        Result(List<double[]> path, double d, double t, List<String> g) {
            this.path = path; this.distanceM = d; this.durationSec = t; this.guides = g;
        }
    }

    /**
     * @param points 첫 번째 출발, 마지막 도착, 가운데는 경유지 (최대 {@value #MAX_VIA} 개). 각 {lat, lon}
     * @throws Exception 호출 실패, 시간 초과, 경로 없음
     */
    public Result route(List<double[]> points) throws Exception {
        if (!enabled()) throw new IllegalStateException("TMAP_APP_KEY 가 설정되지 않았습니다");
        if (points.size() < 2) throw new IllegalArgumentException("출발지와 도착지가 필요합니다");
        if (points.size() - 2 > MAX_VIA) throw new IllegalArgumentException("경유지는 최대 " + MAX_VIA + "개입니다");

        double[] s = points.get(0), e = points.get(points.size() - 1);

        StringBuilder b = new StringBuilder(256);
        b.append('{');
        b.append("\"startX\":").append(Json.num(s[1], 7));
        b.append(",\"startY\":").append(Json.num(s[0], 7));
        b.append(",\"endX\":").append(Json.num(e[1], 7));
        b.append(",\"endY\":").append(Json.num(e[0], 7));
        // Tmap 은 한글 이름을 URL 인코딩해서 받는다
        b.append(",\"startName\":").append(Json.quote(URLEncoder.encode("출발", StandardCharsets.UTF_8)));
        b.append(",\"endName\":").append(Json.quote(URLEncoder.encode("도착", StandardCharsets.UTF_8)));
        b.append(",\"reqCoordType\":\"WGS84GEO\"");
        b.append(",\"resCoordType\":\"WGS84GEO\"");
        b.append(",\"searchOption\":\"0\"");          // 0 = 추천
        if (points.size() > 2) {
            StringBuilder via = new StringBuilder();  // "경도,위도_경도,위도"
            for (int i = 1; i < points.size() - 1; i++) {
                if (via.length() > 0) via.append('_');
                via.append(Json.num(points.get(i)[1], 7)).append(',').append(Json.num(points.get(i)[0], 7));
            }
            b.append(",\"passList\":").append(Json.quote(via.toString()));
        }
        b.append('}');

        HttpRequest req = HttpRequest.newBuilder(URI.create(ENDPOINT))
                .timeout(Duration.ofSeconds(6))
                .header("appKey", appKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(b.toString(), StandardCharsets.UTF_8))
                .build();

        HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        String text = res.body();

        if (res.statusCode() < 200 || res.statusCode() >= 300) {
            throw new Exception("Tmap HTTP " + res.statusCode() + " — "
                    + text.substring(0, Math.min(200, text.length())));
        }

        Map<String, Object> root = Json.asMap(Json.parse(text));
        List<Object> feats = root == null ? null : Json.asList(root.get("features"));
        if (feats == null || feats.isEmpty()) throw new Exception("Tmap 이 경로를 돌려주지 않았습니다");

        List<double[]> path = new ArrayList<>();
        List<String> guides = new ArrayList<>();
        double dist = 0, time = 0;

        for (Object fo : feats) {
            Map<String, Object> f = Json.asMap(fo);
            if (f == null) continue;
            Map<String, Object> props = Json.asMap(f.get("properties"));
            if (props != null) {
                double d = Json.asDouble(props.get("totalDistance"), 0);
                double t = Json.asDouble(props.get("totalTime"), 0);
                if (d != 0) dist = d;
                if (t != 0) time = t;
            }
            Map<String, Object> geom = Json.asMap(f.get("geometry"));
            if (geom == null) continue;
            String type = String.valueOf(geom.get("type"));

            if ("LineString".equals(type)) {
                List<Object> cs = Json.asList(geom.get("coordinates"));
                if (cs == null) continue;
                for (Object co : cs) {
                    List<Object> c = Json.asList(co);
                    if (c == null || c.size() < 2) continue;
                    // Tmap 도 GeoJSON 이라 [경도, 위도] 순서
                    double[] pt = {Json.asDouble(c.get(1), 0), Json.asDouble(c.get(0), 0)};
                    // 선분과 선분이 만나는 지점은 양쪽에 모두 들어오므로 한 번만 넣는다
                    if (!path.isEmpty()) {
                        double[] prev = path.get(path.size() - 1);
                        if (prev[0] == pt[0] && prev[1] == pt[1]) continue;
                    }
                    path.add(pt);
                }
            } else if ("Point".equals(type) && props != null) {
                Object desc = props.get("description");
                if (desc instanceof String && !((String) desc).isEmpty()) guides.add((String) desc);
            }
        }

        if (path.size() < 2) throw new Exception("Tmap 경로 좌표가 비어 있습니다");
        return new Result(path, dist, time, guides);
    }

    /* ───────────── 경유지 뽑기 ───────────── */

    /**
     * 꺾은선에서 길이 기준으로 고르게 경유지를 뽑는다.
     * 안전한 "방향"을 Tmap 에 알려주는 용도이므로 많을 필요가 없다.
     *
     * @param poly  우리 모델이 고른 경로 {lat, lon}
     * @param count 뽑을 개수 (1~{@value #MAX_VIA})
     */
    public static List<double[]> waypoints(List<double[]> poly, int count) {
        List<double[]> out = new ArrayList<>();
        if (poly.size() < 3 || count < 1) return out;
        count = Math.min(count, MAX_VIA);

        double[] cum = new double[poly.size()];
        for (int i = 1; i < poly.size(); i++) {
            cum[i] = cum[i - 1] + haversine(poly.get(i - 1), poly.get(i));
        }
        double total = cum[cum.length - 1];
        if (total <= 0) return out;

        int at = 1;
        for (int k = 1; k <= count; k++) {
            double target = total * k / (count + 1.0);
            while (at < poly.size() - 1 && cum[at] < target) at++;
            out.add(poly.get(at));
        }
        return out;
    }

    static double haversine(double[] a, double[] b) {
        double dLat = Math.toRadians(b[0] - a[0]), dLon = Math.toRadians(b[1] - a[1]);
        double x = Math.pow(Math.sin(dLat / 2), 2)
                + Math.cos(Math.toRadians(a[0])) * Math.cos(Math.toRadians(b[0]))
                  * Math.pow(Math.sin(dLon / 2), 2);
        return 2 * 6371000.0 * Math.asin(Math.sqrt(x));
    }

    /** 꺾은선 전체 길이(m) */
    public static double length(List<double[]> poly) {
        double s = 0;
        for (int i = 1; i < poly.size(); i++) s += haversine(poly.get(i - 1), poly.get(i));
        return s;
    }
}
