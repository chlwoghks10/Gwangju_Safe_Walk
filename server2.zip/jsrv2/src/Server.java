import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLDecoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;

/**
 * 광주 안심길 — 경로 비교 API 서버
 *
 * 팀원들이 준 파일을 그대로 쓴다. 이 파일(Server.java)과 Facilities.java, Json.java 만 우리 것이다.
 *   윤신혁  SafeRoute.java / LatLng.java / RouteServer.java   한 글자도 바꾸지 않음
 *   윤해준  RoadGraph.java / Dijkstra.java                    package 선언만 제거 (기본 패키지)
 *
 * 세 경로
 *   shortest  최단   거리만 (윤해준 Dijkstra)
 *   safest    안심 A 간선별 safe_cost (윤해준 Dijkstra)
 *   safest2   안심 B 윤신혁 SafeRoute.planSafeRoute
 *             경유지 후보를 pickViaPoints 가 고르고, 후보마다 RouteProvider 로 경로를 받아
 *             scoreRoute 로 채점한 뒤 total 최소를 채택한다.
 *             RouteProvider 는 두 가지를 쓴다 (조장이 교체 가능하게 만들어 둔 지점).
 *               1순위  조장 RouteServer (127.0.0.1:3000) -> Tmap 보행 경로, 골목 포함
 *               대체   우리 도로망 + 윤해준 Dijkstra
 *
 * 빌드   javac -encoding UTF-8 -cp lib/gson-2.11.0.jar -d out src/*.java
 * 실행   java -cp out:lib/gson-2.11.0.jar Server [포트] [데이터폴더]
 * 확인   http://<주소>:8000/health
 */
public class Server {

    /** 요청 좌표가 도로망에서 이만큼 멀면 거부 */
    private static final double MAX_SNAP_METERS = 300.0;

    /** 조장 RouteServer 주소. 외부에 열지 않고 같은 EC2 안에서만 부른다 */
    private static final String PROXY =
            System.getenv().getOrDefault("ROUTE_PROXY", "http://127.0.0.1:3000/api/route");

    /**
     * 후보가 3~5개라 Tmap 호출도 그만큼 일어난다. 앱 읽기 제한(12초) 안에 반드시 응답하도록
     * 전체 시간 예산을 둔다. 예산을 넘긴 후보는 호출하지 않고 건너뛴다.
     * (planSafeRoute 가 후보별 실패를 이미 건너뛰도록 되어 있어 조장 코드는 손대지 않았다)
     */
    private static final long BUDGET_NANOS = 8_000_000_000L;

    private static RoadGraph graph;
    private static Facilities facilities;
    private static SafeRoute.Index safeIdx;
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(2)).build();

    /**
     * sRef 는 조장 기본값 2.5 를 그대로 둔다. 조장 Test.java 를 실제 광주 데이터로 돌려
     * 노드 점수 분포가 p10 0.00 / p50 1.06 / p75 2.75 / p90 4.15 임을 확인했고,
     * 2.5 에서 경로가 가장 잘 구분된다 (p50 으로 낮추면 안전도가 1.0 으로 포화되어 구분 불가).
     */
    private static final SafeRoute.Options SAFE_OPT = new SafeRoute.Options();

    public static void main(String[] args) throws Exception {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : 8000;
        Path dataDir = Paths.get(args.length > 1 ? args[1] : "data");

        long t0 = System.nanoTime();
        try (InputStream nodes = Files.newInputStream(dataDir.resolve("graph_nodes.csv"));
             InputStream edges = Files.newInputStream(dataDir.resolve("graph_edges.csv"))) {
            graph = RoadGraph.load(nodes, edges);
        }
        System.out.printf("[graph] 노드 %,d / 간선 %,d  (%.0fms)%n",
                graph.nodeCount, graph.arcCount, (System.nanoTime() - t0) / 1e6);

        facilities = new Facilities(dataDir);

        long t1 = System.nanoTime();
        safeIdx = SafeRoute.buildIndex(SafeRoute.toFacilities(loadGeo(dataDir)));
        System.out.printf("[saferoute] 시설 %,d지점 / sRef %.1f / 경유지 후보 최대 %d개  (%.0fms)%n",
                safeIdx.facilities.size(), SAFE_OPT.sRef, SAFE_OPT.numVia, (System.nanoTime() - t1) / 1e6);
        System.out.println("[saferoute] 경로 제공자 1순위: " + PROXY + " (조장 RouteServer)");

        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/health", Server::handleHealth);
        server.createContext("/route",  Server::handleRoute);
        server.createContext("/",       Server::handleRoot);
        server.setExecutor(Executors.newFixedThreadPool(4));
        server.start();

        System.out.println("[server] http://0.0.0.0:" + port + " 에서 대기 중");
    }

    /** 조장 Test.java 의 geojson 읽는 부분과 같다 */
    private static Map<String, JsonObject> loadGeo(Path dir) {
        Map<String, JsonObject> geo = new HashMap<>();
        for (SafeRoute.Type type : SafeRoute.Type.values()) {
            Path p = dir.resolve(type.key() + ".geojson");
            if (!Files.exists(p)) {
                System.out.println("[saferoute] " + p.getFileName() + " 없음 — 건너뜀");
                continue;
            }
            try {
                String text = Files.readString(p, StandardCharsets.UTF_8);
                geo.put(type.key(), JsonParser.parseString(text).getAsJsonObject());
            } catch (Exception e) {
                System.out.println("[saferoute] " + p.getFileName() + " 읽기 실패: " + e.getMessage());
            }
        }
        return geo;
    }

    /* ───────────── 경로 제공자 (조장이 교체 가능하게 만들어 둔 지점) ───────────── */

    /** 1순위: 조장 RouteServer 를 불러 Tmap 보행 경로를 받는다 */
    private static List<LatLng> viaProxy(List<LatLng> wps) throws Exception {
        StringBuilder pts = new StringBuilder();
        for (LatLng p : wps) {
            if (pts.length() > 0) pts.append(';');
            pts.append(Json.num(p.lat(), 7)).append(',').append(Json.num(p.lng(), 7));
        }
        HttpRequest req = HttpRequest.newBuilder(URI.create(PROXY + "?points=" + pts))
                .timeout(Duration.ofSeconds(7))
                .GET()
                .build();
        HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        JsonObject o = JsonParser.parseString(res.body()).getAsJsonObject();
        if (res.statusCode() != 200) {
            JsonElement err = o.get("error");
            throw new Exception("RouteServer " + res.statusCode()
                    + (err == null ? "" : " — " + err.getAsString()));
        }
        List<LatLng> out = new ArrayList<>();
        for (JsonElement e : o.getAsJsonArray("path")) {
            JsonObject c = e.getAsJsonObject();
            out.add(new LatLng(c.get("lat").getAsDouble(), c.get("lng").getAsDouble()));
        }
        if (out.size() < 2) throw new Exception("RouteServer 경로 좌표가 비어 있습니다");
        return out;
    }

    /** 대체: 우리 도로망 + 윤해준 Dijkstra 로 경유지를 잇는다 */
    private static List<LatLng> viaGraph(List<LatLng> wps) throws Exception {
        List<LatLng> out = new ArrayList<>();
        for (int i = 0; i + 1 < wps.size(); i++) {
            int a = graph.nearestNode(wps.get(i).lat(), wps.get(i).lng());
            int b = graph.nearestNode(wps.get(i + 1).lat(), wps.get(i + 1).lng());
            if (a == b) continue;
            Dijkstra.Result r = Dijkstra.shortestPath(graph, a, b, graph.length);
            if (r == null) throw new Exception("도로망에서 이어지지 않는 구간이 있습니다");
            for (double[] c : graph.coordsOf(r.arcs)) {
                LatLng p = new LatLng(c[0], c[1]);
                if (!out.isEmpty()) {
                    LatLng prev = out.get(out.size() - 1);
                    if (prev.lat() == p.lat() && prev.lng() == p.lng()) continue;
                }
                out.add(p);
            }
        }
        if (out.size() < 2) throw new Exception("경로 좌표가 비어 있습니다");
        return out;
    }

    /* ───────────── 엔드포인트 ───────────── */

    private static void handleRoot(HttpExchange ex) throws IOException {
        send(ex, 200, "{\"service\":\"광주 안심길 경로 API\",\"endpoints\":[\"/health\",\"/route\"]}");
    }

    private static void handleHealth(HttpExchange ex) throws IOException {
        double minLat = Double.MAX_VALUE, maxLat = -Double.MAX_VALUE;
        double minLon = Double.MAX_VALUE, maxLon = -Double.MAX_VALUE;
        for (int i = 0; i < graph.nodeCount; i++) {
            minLat = Math.min(minLat, graph.lat[i]); maxLat = Math.max(maxLat, graph.lat[i]);
            minLon = Math.min(minLon, graph.lon[i]); maxLon = Math.max(maxLon, graph.lon[i]);
        }

        StringBuilder b = new StringBuilder();
        b.append("{\"status\":\"ok\"");
        b.append(",\"nodes\":").append(graph.nodeCount);
        b.append(",\"arcs\":").append(graph.arcCount);
        b.append(",\"saferoute_facilities\":").append(safeIdx.facilities.size());
        b.append(",\"route_proxy\":").append(Json.quote(PROXY));
        b.append(",\"facility_layers\":{");
        boolean first = true;
        for (Map.Entry<String, Integer> e : facilities.layerSizes().entrySet()) {
            if (!first) b.append(',');
            first = false;
            b.append(Json.quote(e.getKey())).append(':').append(e.getValue());
        }
        b.append("},\"bounds\":{");
        b.append("\"min_lat\":").append(Json.num(minLat, 6));
        b.append(",\"max_lat\":").append(Json.num(maxLat, 6));
        b.append(",\"min_lon\":").append(Json.num(minLon, 6));
        b.append(",\"max_lon\":").append(Json.num(maxLon, 6));
        b.append("}}");
        send(ex, 200, b.toString());
    }

    private static void handleRoute(HttpExchange ex) throws IOException {
        long t0 = System.nanoTime();
        Map<String, String> q = query(ex.getRequestURI().getRawQuery());

        Double sLat = num(q.get("start_lat")), sLon = num(q.get("start_lon"));
        Double eLat = num(q.get("end_lat")),   eLon = num(q.get("end_lon"));
        if (sLat == null || sLon == null || eLat == null || eLon == null) {
            error(ex, 422, "start_lat, start_lon, end_lat, end_lon 이 모두 필요합니다");
            return;
        }
        boolean withFacilities = !"false".equalsIgnoreCase(q.getOrDefault("facilities", "true"));

        int src = graph.nearestNode(sLat, sLon);
        int dst = graph.nearestNode(eLat, eLon);
        double dSrc = graph.distanceToNode(src, sLat, sLon);
        double dDst = graph.distanceToNode(dst, eLat, eLon);

        if (dSrc > MAX_SNAP_METERS || dDst > MAX_SNAP_METERS) {
            error(ex, 400, String.format("도로망 범위 밖입니다 (출발 %.0fm, 도착 %.0fm)", dSrc, dDst));
            return;
        }
        if (src == dst) {
            error(ex, 400, "출발지와 도착지가 너무 가깝습니다");
            return;
        }

        Dijkstra.Result shortest = Dijkstra.shortestPath(graph, src, dst, graph.length);
        Dijkstra.Result safest   = Dijkstra.shortestPath(graph, src, dst, graph.safeCost);
        if (shortest == null || safest == null) {
            error(ex, 404, "두 지점이 도로망에서 이어지지 않습니다");
            return;
        }

        // ── 안심 B: 조장 planSafeRoute. 제공자를 Tmap -> 도로망 순으로 시도한다 ──
        LatLng origin = new LatLng(sLat, sLon), dest = new LatLng(eLat, eLon);
        List<LatLng> coords2 = null;
        double length2 = 0;
        String source2 = null, label2 = null;

        for (String which : new String[]{"tmap", "graph"}) {
            final long deadline = System.nanoTime() + BUDGET_NANOS;
            final boolean proxy = "tmap".equals(which);
            SafeRoute.RouteProvider provider = wps -> {
                if (System.nanoTime() > deadline) throw new Exception("시간 예산 초과 — 후보 건너뜀");
                return proxy ? viaProxy(wps) : viaGraph(wps);
            };
            try {
                SafeRoute.PlanResult plan =
                        SafeRoute.planSafeRoute(origin, dest, safeIdx, provider, SAFE_OPT);
                for (SafeRoute.RouteResult r : plan.all()) {
                    SafeRoute.Score s = r.score();
                    System.out.printf("[saferoute:%s] %-12s %5.0fm  평균안전도 %.2f  취약 %.2f  total %6.0f%s%n",
                            which, r.label(), s.distance(), s.meanSafety(), s.weakRatio(), s.total(),
                            r == plan.best() ? "  <= 채택" : "");
                }
                coords2 = plan.best().path();
                length2 = plan.best().score().distance();
                source2 = which;
                label2  = plan.best().label();
                break;
            } catch (Exception e) {
                System.out.println("[saferoute:" + which + "] 실패: " + e.getMessage());
            }
        }

        boolean same = java.util.Arrays.equals(shortest.arcs, safest.arcs);

        StringBuilder b = new StringBuilder(1 << 16);
        b.append("{\"shortest\":");
        appendRoute(b, toCoords(graph.coordsOf(shortest.arcs)), shortest.lengthM, withFacilities);
        b.append(",\"safest\":");
        appendRoute(b, toCoords(graph.coordsOf(safest.arcs)), safest.lengthM, withFacilities);
        b.append(",\"safest2\":");
        if (coords2 == null) {
            // 두 제공자가 모두 실패한 경우에만. 앱이 칸을 비우지 않도록 안심 A 를 넣는다.
            appendRoute(b, toCoords(graph.coordsOf(safest.arcs)), safest.lengthM, withFacilities);
            source2 = "none";
            label2  = "안심 A 와 동일 (경로를 받지 못함)";
            length2 = safest.lengthM;
        } else {
            appendRoute(b, coords2, length2, withFacilities);
        }
        b.append(",\"same\":").append(same);
        b.append(",\"safest2_source\":").append(Json.quote(source2));
        b.append(",\"safest2_label\":").append(Json.quote(label2));
        b.append(",\"extra_m\":").append(Json.num(safest.lengthM - shortest.lengthM, 1));
        b.append(",\"extra2_m\":").append(Json.num(length2 - shortest.lengthM, 1));
        b.append(",\"elapsed_ms\":").append(Json.num((System.nanoTime() - t0) / 1e6, 1));
        b.append('}');
        send(ex, 200, b.toString());
    }

    private static List<LatLng> toCoords(List<double[]> raw) {
        List<LatLng> out = new ArrayList<>(raw.size());
        for (double[] c : raw) out.add(new LatLng(c[0], c[1]));
        return out;
    }

    /** 한 경로를 JSON 객체로. 시설 개수는 세 경로 모두 같은 기준(반경 10m, 대수 합) */
    private static void appendRoute(StringBuilder b, List<LatLng> coords, double lengthM,
                                    boolean withFacilities) {
        List<double[]> raw = new ArrayList<>(coords.size());
        for (LatLng p : coords) raw.add(new double[]{p.lat(), p.lng()});
        Map<String, List<Facilities.Hit>> fac =
                withFacilities ? facilities.nearPolyline(raw) : new HashMap<>();

        b.append("{\"length_m\":").append(Json.num(lengthM, 1));
        b.append(",\"cctv\":").append(count(fac, "cctv"));
        b.append(",\"light\":").append(count(fac, "light"));
        b.append(",\"bell\":").append(count(fac, "bell"));
        b.append(",\"police\":").append(count(fac, "police"));

        b.append(",\"coords\":[");
        for (int i = 0; i < coords.size(); i++) {
            if (i > 0) b.append(',');
            b.append('[').append(Json.num(coords.get(i).lat(), 6)).append(',')
             .append(Json.num(coords.get(i).lng(), 6)).append(']');
        }
        b.append(']');

        b.append(",\"facilities\":{");
        boolean firstLayer = true;
        for (Map.Entry<String, List<Facilities.Hit>> e : fac.entrySet()) {
            if (!firstLayer) b.append(',');
            firstLayer = false;
            b.append(Json.quote(e.getKey())).append(":[");
            List<Facilities.Hit> hits = e.getValue();
            for (int i = 0; i < hits.size(); i++) {
                if (i > 0) b.append(',');
                Facilities.Hit h = hits.get(i);
                b.append('[').append(Json.num(h.lat, 6)).append(',')
                 .append(Json.num(h.lon, 6)).append(',').append(h.cnt).append(']');
            }
            b.append(']');
        }
        b.append("}}");
    }

    /** 지점 수가 아니라 대수(개수) 합을 센다 */
    private static int count(Map<String, List<Facilities.Hit>> fac, String key) {
        List<Facilities.Hit> v = fac.get(key);
        if (v == null) return 0;
        int n = 0;
        for (Facilities.Hit h : v) n += h.cnt;
        return n;
    }

    /* ───────────── 보조 ───────────── */

    private static Map<String, String> query(String raw) {
        Map<String, String> m = new HashMap<>();
        if (raw == null || raw.isEmpty()) return m;
        for (String pair : raw.split("&")) {
            int i = pair.indexOf('=');
            if (i <= 0) continue;
            try {
                m.put(URLDecoder.decode(pair.substring(0, i), "UTF-8"),
                      URLDecoder.decode(pair.substring(i + 1), "UTF-8"));
            } catch (IOException ignored) { }
        }
        return m;
    }

    private static Double num(String s) {
        if (s == null || s.isEmpty()) return null;
        try { return Double.valueOf(s.trim()); } catch (NumberFormatException e) { return null; }
    }

    private static void error(HttpExchange ex, int code, String detail) throws IOException {
        send(ex, code, "{\"detail\":" + Json.quote(detail) + "}");
    }

    private static void send(HttpExchange ex, int code, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
        ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        ex.sendResponseHeaders(code, bytes.length);
        ex.getResponseBody().write(bytes);
        ex.close();
    }
}
