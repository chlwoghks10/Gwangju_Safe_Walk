광주 안심길 — 경로 비교 API 서버

[팀원 파일은 그대로 쓴다]
  src/SafeRoute.java      윤신혁 — 원본과 완전 동일 (cmp 로 확인)
  src/LatLng.java         윤신혁 — 원본과 완전 동일
  src/RouteServer.java    윤신혁 — 원본과 완전 동일
  src/RoadGraph.java      윤해준 — package 선언만 제거 (기본 패키지)
  src/Dijkstra.java       윤해준 — package 선언만 제거

  우리가 쓴 파일은 셋뿐이다.
  src/Server.java         경로 비교 엔드포인트
  src/Facilities.java     경로 주변 시설 조회 (반경 10m, 좌표 중복 합침)
  src/Json.java           응답 만들기용 최소 도구

  조장 안내대로 Test.java 는 넣지 않았다 (로컬 검증용).
  SafeRoute.java 가 Gson 을 쓰므로 gson jar 가 필요하다 (아래 [준비] 참고).

[서버 두 개가 뜬다]
  3000  RouteServer   윤신혁 원본. Tmap 보행경로 프록시. 원본대로 127.0.0.1 에만
                      바인딩하므로 외부에 공개되지 않고 같은 EC2 안에서만 불린다.
  8000  Server        앱이 부르는 경로 비교 API.

[세 가지 경로]
  shortest  최단   거리만 (윤해준 Dijkstra)
  safest    안심 A 간선별 safe_cost (윤해준 Dijkstra)
  safest2   안심 B 윤신혁 SafeRoute.planSafeRoute
            1) pickViaPoints 로 출발-도착 직선 주변 300m 코리도를 훑어
               안전 점수 높은 경유지를 최대 4개 고른다 (서로 250m 이상)
            2) "기본 경로"(경유지 없음) 와 "경유 후보 N"(경유지 1개) 를 각각
               RouteProvider 로 보내 실제 걸을 수 있는 경로를 받는다
            3) scoreRoute 로 채점: total = 거리 x (1 + alpha x 부족도)
               최단 대비 1.35배 넘는 후보는 제외하고 total 최소를 채택

            RouteProvider 는 조장이 교체 가능하게 만들어 둔 지점이다. 두 개를 쓴다.
              1순위  RouteServer (127.0.0.1:3000) -> Tmap, 골목 포함
              대체   우리 도로망 + 윤해준 Dijkstra
            응답의 safest2_source 가 "tmap" / "graph" 로 어느 쪽인지 알려주고,
            safest2_label 이 채택된 후보 이름("기본 경로" / "경유 후보 N")을 알려준다.

  sRef 는 조장 기본값 2.5 를 그대로 둔다. 조장 Test.java 를 실제 광주 데이터로 돌려
  노드 점수 분포가 p10 0.00 / p50 1.06 / p75 2.75 / p90 4.15 임을 확인했고,
  2.5 에서 경로가 가장 잘 구분된다 (p50 으로 낮추면 안전도가 1.0 으로 포화됨).

  시설 개수는 세 경로 모두 같은 기준(반경 10m, 대수 합)으로 센다.

[호출 횟수와 시간]
  후보가 3~5개이므로 한 번의 /route 요청에 Tmap 을 그만큼 호출한다.
  앱 읽기 제한(12초)을 넘지 않도록 Server 쪽에 전체 8초 예산을 두었다.
  예산을 넘긴 후보는 호출하지 않고 건너뛴다. 조장 알고리즘은 손대지 않았다.

[장소 검색]
  GET /search?q=명륜진사갈비 문흥점
  카카오 로컬 키워드 검색을 서버가 대신 불러 준다. 앱이 직접 부르지 않는 이유는 키 때문이다.
  (앱에 키를 넣으면 APK 를 뜯어서 꺼낼 수 있다)

  검색은 조선대(35.14, 126.927) 기준 반경 20km 안에서 가까운 순으로 15건까지 돌려준다.
  각 결과의 in_range 는 그 지점이 우리 도로망 안인지를 알려준다.
  밖이면 경로를 만들 수 없으므로 앱에서 미리 안내할 수 있다.

  응답: { "places": [ {name, address, category, lat, lon, in_range} ... ] }

[준비 — EC2 에서 한 번만]
  sudo apt update
  sudo apt install -y openjdk-21-jdk-headless

  mkdir -p ~/lib
  curl -L -o ~/lib/gson-2.11.0.jar \
    https://repo1.maven.org/maven2/com/google/code/gson/gson/2.11.0/gson-2.11.0.jar

  echo 'TMAP_APP_KEY=발급받은Tmap키'    > ~/safewalk.env
  echo 'KAKAO_REST_KEY=발급받은카카오키' >> ~/safewalk.env
  chmod 600 ~/safewalk.env
  * 두 번째 줄은 >> 입니다 (> 로 쓰면 첫 줄이 지워집니다)
  * 소스와 깃허브에는 키를 넣지 않는다. 공개 저장소의 키는 몇 분 안에 수집된다.

[빌드]
  javac -encoding UTF-8 -cp ~/lib/gson-2.11.0.jar -d out src/*.java

[항상 켜두기]
  sudo cp safewalk-tmap.service safewalk.service /etc/systemd/system/
  sudo systemctl daemon-reload
  sudo systemctl enable safewalk-tmap safewalk
  sudo systemctl restart safewalk-tmap safewalk
  sudo journalctl -u safewalk -n 20 --no-pager

  기동 로그에 다음이 보이면 정상이다:
    [graph]     노드 / 간선 개수
    [saferoute] 시설 지점 수 / sRef 2.5 / 경유지 후보 최대 4개
    [saferoute] 경로 제공자 1순위: http://127.0.0.1:3000/api/route (조장 RouteServer)
    [search]    키 확인 — 카카오 로컬 장소 검색을 쓸 수 있습니다

[확인]
  http://<주소>:8000/health
  http://<주소>:8000/route?start_lat=35.1445&start_lon=126.9245&end_lat=35.1360&end_lon=126.9310

[응답 형식]
  GET /route?start_lat=&start_lon=&end_lat=&end_lon=
  { "shortest": {length_m, cctv, light, bell, police, coords, facilities},
    "safest":   {...},            안심 A (윤해준)
    "safest2":  {...},            안심 B (윤신혁 SafeRoute + Tmap)
    "same": bool,
    "safest2_source": "tmap" | "graph" | "none",
    "safest2_label": "기본 경로" | "경유 후보 N",
    "extra_m": ..., "extra2_m": ..., "elapsed_ms": ... }

  앱은 수정할 필요가 없다.
