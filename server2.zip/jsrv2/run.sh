#!/bin/bash
# 광주 안심길 — 빌드 후 두 서버 실행 (로컬 확인용)
cd "$(dirname "$0")"
CP="out:lib/gson-2.11.0.jar"
javac -encoding UTF-8 -cp lib/gson-2.11.0.jar -d out src/*.java || exit 1
java -Dstdout.encoding=UTF-8 -cp "$CP" RouteServer &
sleep 1
exec java -Dstdout.encoding=UTF-8 -cp "$CP" Server "${1:-8000}" data
