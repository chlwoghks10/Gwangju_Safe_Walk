package safewalk;

import java.util.Arrays;
import java.util.PriorityQueue;

/**
 * 다익스트라 최단경로 (우선순위 큐 사용, O((V+E) log V)).
 * 같은 그래프에 weight 배열만 바꿔서 호출하면 최단경로 / 안전경로를 각각 구할 수 있다.
 */
public final class Dijkstra {

    private Dijkstra() {}

    /** 탐색 결과: 지나간 간선 id 목록과 구간 합계 */
    public static final class Result {
        public final int[] arcs;
        public final double cost;       // 사용한 weight 기준 총 비용
        public final double lengthM;    // 총 거리(m)
        public final int cctv;          // 경로 구간들의 CCTV 합
        public final int light;         // 경로 구간들의 보안등 합

        Result(RoadGraph g, int[] arcs, double cost) {
            this.arcs = arcs;
            this.cost = cost;
            double len = 0;
            int c = 0, l = 0;
            for (int a : arcs) {
                len += g.length[a];
                c += g.cctv[a];
                l += g.light[a];
            }
            this.lengthM = len;
            this.cctv = c;
            this.light = l;
        }
    }

    private static final class Entry implements Comparable<Entry> {
        final int node;
        final double dist;
        Entry(int node, double dist) { this.node = node; this.dist = dist; }
        @Override public int compareTo(Entry o) { return Double.compare(dist, o.dist); }
    }

    /**
     * @param weight 간선 id 별 비용 (모두 0 이상이어야 함)
     * @return 경로 결과, 도달 불가능하면 null
     */
    public static Result shortestPath(RoadGraph g, int src, int dst, double[] weight) {
        double[] dist = new double[g.nodeCount];
        int[] prevArc = new int[g.nodeCount];
        Arrays.fill(dist, Double.POSITIVE_INFINITY);
        Arrays.fill(prevArc, -1);

        PriorityQueue<Entry> pq = new PriorityQueue<>();
        dist[src] = 0;
        pq.add(new Entry(src, 0));

        while (!pq.isEmpty()) {
            Entry cur = pq.poll();
            if (cur.dist > dist[cur.node]) continue;   // 이미 더 짧은 경로로 확정된 낡은 항목
            if (cur.node == dst) break;                // 목적지 확정 → 조기 종료
            for (int i = g.outStart(cur.node); i < g.outEnd(cur.node); i++) {
                int a = g.adjArcAt(i);
                int next = g.to[a];
                double nd = cur.dist + weight[a];
                if (nd < dist[next]) {
                    dist[next] = nd;
                    prevArc[next] = a;
                    pq.add(new Entry(next, nd));
                }
            }
        }
        if (Double.isInfinite(dist[dst])) return null;

        // 목적지에서 거슬러 올라가며 간선 복원
        int count = 0;
        for (int n = dst; n != src; n = g.from[prevArc[n]]) count++;
        int[] arcs = new int[count];
        int n = dst;
        for (int i = count - 1; i >= 0; i--) {
            arcs[i] = prevArc[n];
            n = g.from[prevArc[n]];
        }
        return new Result(g, arcs, dist[dst]);
    }
}
