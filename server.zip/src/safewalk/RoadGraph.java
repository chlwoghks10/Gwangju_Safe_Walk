package safewalk;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 보행 도로망 그래프 (안드로이드 의존성 없음).
 * assets/graph_nodes.csv, assets/graph_edges.csv 를 읽어 인접 리스트(CSR)로 보관한다.
 * 간선(arc)은 방향이 있으며, 파이썬 export_graph.py 가 양방향을 모두 내보낸다.
 */
public class RoadGraph {

    public final int nodeCount;
    public final double[] lat, lon;

    public final int arcCount;
    public final int[] from, to;
    public final double[] length;     // 구간 길이(m)
    public final double[] safeCost;   // 안전 우선 경로용 통행 비용 (노트북의 비용 함수 결과)
    public final int[] cctv, light;   // 구간 주변 시설 수
    public final double[][] geom;     // 구간 꺾은선 [lat0,lon0,lat1,lon1,...], 없으면 null

    private final int[] adjStart;     // 노드별 나가는 간선 시작 위치
    private final int[] adjArcs;      // 나가는 간선 id 목록

    private RoadGraph(double[] lat, double[] lon, int[] from, int[] to, double[] length,
                      double[] safeCost, int[] cctv, int[] light, double[][] geom) {
        this.nodeCount = lat.length;
        this.lat = lat;
        this.lon = lon;
        this.arcCount = from.length;
        this.from = from;
        this.to = to;
        this.length = length;
        this.safeCost = safeCost;
        this.cctv = cctv;
        this.light = light;
        this.geom = geom;

        adjStart = new int[nodeCount + 1];
        for (int a = 0; a < arcCount; a++) adjStart[from[a] + 1]++;
        for (int i = 0; i < nodeCount; i++) adjStart[i + 1] += adjStart[i];
        adjArcs = new int[arcCount];
        int[] fill = new int[nodeCount];
        for (int a = 0; a < arcCount; a++) {
            adjArcs[adjStart[from[a]] + fill[from[a]]++] = a;
        }
    }

    /** 노드 n 에서 나가는 간선 id 범위 [start, end) 를 adjArcAt 으로 접근 */
    public int outStart(int n) { return adjStart[n]; }
    public int outEnd(int n)   { return adjStart[n + 1]; }
    public int adjArcAt(int i) { return adjArcs[i]; }

    // ───────────────────────── 로딩 ─────────────────────────

    public static RoadGraph load(InputStream nodesCsv, InputStream edgesCsv) throws IOException {
        // 노드
        Map<Long, Integer> idToIndex = new HashMap<>();
        List<double[]> nodes = new ArrayList<>();
        try (BufferedReader r = reader(nodesCsv)) {
            Map<String, Integer> col = header(r.readLine());
            int cId = col("id", col), cLat = col("lat", col), cLon = col("lon", col);
            String line;
            while ((line = r.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] f = line.split(",", -1);
                idToIndex.put(Long.parseLong(f[cId].trim()), nodes.size());
                nodes.add(new double[]{Double.parseDouble(f[cLat]), Double.parseDouble(f[cLon])});
            }
        }
        double[] lat = new double[nodes.size()], lon = new double[nodes.size()];
        for (int i = 0; i < nodes.size(); i++) {
            lat[i] = nodes.get(i)[0];
            lon[i] = nodes.get(i)[1];
        }

        // 간선
        List<int[]> ends = new ArrayList<>();       // {from,to,cctv,light}
        List<double[]> costs = new ArrayList<>();   // {length,safeCost}
        List<double[]> geoms = new ArrayList<>();
        try (BufferedReader r = reader(edgesCsv)) {
            Map<String, Integer> col = header(r.readLine());
            int cU = col("u", col), cV = col("v", col), cLen = col("length", col),
                cCctv = col("cctv", col), cLight = col("light", col), cCost = col("safe_cost", col);
            Integer cGeom = col.get("geom");
            String line;
            while ((line = r.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] f = line.split(",", -1);
                Integer u = idToIndex.get(Long.parseLong(f[cU].trim()));
                Integer v = idToIndex.get(Long.parseLong(f[cV].trim()));
                if (u == null || v == null) continue;
                ends.add(new int[]{u, v,
                        (int) Math.round(Double.parseDouble(f[cCctv])),
                        (int) Math.round(Double.parseDouble(f[cLight]))});
                costs.add(new double[]{Double.parseDouble(f[cLen]), Double.parseDouble(f[cCost])});
                geoms.add(cGeom != null && cGeom < f.length ? parseGeom(f[cGeom]) : null);
            }
        }
        int m = ends.size();
        int[] from = new int[m], to = new int[m], cctv = new int[m], light = new int[m];
        double[] length = new double[m], safeCost = new double[m];
        double[][] geom = new double[m][];
        for (int a = 0; a < m; a++) {
            from[a] = ends.get(a)[0];
            to[a] = ends.get(a)[1];
            cctv[a] = ends.get(a)[2];
            light[a] = ends.get(a)[3];
            length[a] = costs.get(a)[0];
            safeCost[a] = costs.get(a)[1];
            geom[a] = geoms.get(a);
        }
        return new RoadGraph(lat, lon, from, to, length, safeCost, cctv, light, geom);
    }

    /** "lat lon|lat lon|..." → [lat,lon,lat,lon,...] */
    private static double[] parseGeom(String s) {
        s = s.trim();
        if (s.isEmpty()) return null;
        String[] pts = s.split("\\|");
        double[] out = new double[pts.length * 2];
        for (int i = 0; i < pts.length; i++) {
            String[] ll = pts[i].trim().split("\\s+");
            out[2 * i] = Double.parseDouble(ll[0]);
            out[2 * i + 1] = Double.parseDouble(ll[1]);
        }
        return out;
    }

    private static BufferedReader reader(InputStream in) {
        return new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
    }

    private static Map<String, Integer> header(String line) {
        if (line == null) throw new IllegalArgumentException("빈 CSV 파일입니다");
        if (line.startsWith("\uFEFF")) line = line.substring(1);
        Map<String, Integer> m = new HashMap<>();
        String[] h = line.split(",", -1);
        for (int i = 0; i < h.length; i++) m.put(h[i].trim(), i);
        return m;
    }

    private static int col(String name, Map<String, Integer> m) {
        Integer i = m.get(name);
        if (i == null) throw new IllegalArgumentException("CSV에 '" + name + "' 열이 없습니다");
        return i;
    }

    // ───────────────────────── 조회 ─────────────────────────

    /** 좌표에서 가장 가까운 노드 인덱스 */
    public int nearestNode(double la, double lo) {
        int best = -1;
        double bestD = Double.MAX_VALUE;
        for (int i = 0; i < nodeCount; i++) {
            double d = distanceMeters(la, lo, lat[i], lon[i]);
            if (d < bestD) { bestD = d; best = i; }
        }
        return best;
    }

    public double distanceToNode(int node, double la, double lo) {
        return distanceMeters(la, lo, lat[node], lon[node]);
    }

    /** 근거리용 등장방형 근사 거리(m) */
    public static double distanceMeters(double la1, double lo1, double la2, double lo2) {
        double dLat = Math.toRadians(la2 - la1);
        double dLon = Math.toRadians(lo2 - lo1) * Math.cos(Math.toRadians((la1 + la2) / 2));
        return 6371000.0 * Math.sqrt(dLat * dLat + dLon * dLon);
    }

    /** 간선 경로를 지도에 그릴 좌표열 {lat,lon} 로 변환 (꺾은선 포함, 연속 중복점 제거) */
    public List<double[]> coordsOf(int[] arcs) {
        List<double[]> out = new ArrayList<>();
        for (int a : arcs) {
            double[] g = geom[a];
            if (g == null || g.length < 4) {
                add(out, lat[from[a]], lon[from[a]]);
                add(out, lat[to[a]], lon[to[a]]);
            } else {
                for (int i = 0; i < g.length; i += 2) add(out, g[i], g[i + 1]);
            }
        }
        return out;
    }

    private static void add(List<double[]> out, double la, double lo) {
        if (!out.isEmpty()) {
            double[] last = out.get(out.size() - 1);
            if (last[0] == la && last[1] == lo) return;
        }
        out.add(new double[]{la, lo});
    }
}
