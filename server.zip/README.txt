광주 안심길 — 경로 비교 API 서버 (자바)

[구성]
  src/safewalk/RoadGraph.java   팀원 작성 (package 선언만 변경)
  src/safewalk/Dijkstra.java    팀원 작성 (package 선언만 변경)
  src/safewalk/Facilities.java  경로 주변 시설 조회
  src/safewalk/Json.java        최소 JSON 도구
  src/safewalk/Server.java      HTTP 엔드포인트 (JDK 내장 HttpServer)
  data/                         graph_nodes.csv, graph_edges.csv
                                + 앱 assets 의 geojson 4개를 복사해 넣을 것

외부 라이브러리가 없어 Maven / Gradle 없이 javac 만으로 빌드된다.

[EC2 준비]
  sudo apt update
  sudo apt install -y openjdk-21-jdk-headless

[빌드]
  javac -encoding UTF-8 -d out src/safewalk/*.java

[실행]
  java -Dstdout.encoding=UTF-8 -cp out safewalk.Server 8000 data

[항상 켜두기]
  sudo cp safewalk.service /etc/systemd/system/safewalk.service
  sudo systemctl daemon-reload
  sudo systemctl enable safewalk
  sudo systemctl restart safewalk
  sudo systemctl status safewalk

[확인]
  http://<주소>:8000/health
  http://<주소>:8000/route?start_lat=35.1445&start_lon=126.9245&end_lat=35.1360&end_lon=126.9310

[응답 형식] 파이썬 서버와 동일하므로 앱은 수정할 필요가 없다.
  { "shortest": {length_m, cctv, light, bell, police, coords, facilities},
    "safest":   {...}, "same": bool, "extra_m": ..., "elapsed_ms": ... }

[동작 확인 결과]
  - 팀원 자바 코드를 그대로 사용 (package 선언만 변경, diff 로 확인)
  - 무작위 10쌍 경로에서 파이썬 독립 구현과 거리 완전 일치
  - 조선대 기준 예시: 최단 1,606m / 안전 2,359m (추가 752.5m)
  - 응답 3.2ms, 약 8KB
