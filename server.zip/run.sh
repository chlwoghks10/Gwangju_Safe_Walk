#!/bin/bash
# 광주 안심길 자바 서버 — 빌드 후 실행
cd "$(dirname "$0")"
javac -encoding UTF-8 -d out src/safewalk/*.java || exit 1
exec java -Dstdout.encoding=UTF-8 -cp out safewalk.Server "${1:-8000}" data
